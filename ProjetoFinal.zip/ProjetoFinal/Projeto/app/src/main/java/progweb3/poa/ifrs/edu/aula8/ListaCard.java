package progweb3.poa.ifrs.edu.aula8;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ListaCard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_card);
    }
}
